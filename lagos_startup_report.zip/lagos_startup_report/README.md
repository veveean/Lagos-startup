
# Lagos Startup Report 2025 – Landing Page

This package contains a single‑page static website (`index.html`) built with Tailwind CSS and Chart.js.

## Preview locally

```bash
python3 -m http.server 8000
# then open http://localhost:8000
```

## Deploy to the web

### GitHub Pages
1. Create a new repository and commit `index.html`.
2. Go to **Settings → Pages**, choose **Branch: `main` / root**.
3. Save. Your site will appear at `https://<github-username>.github.io/<repo>/`.

### Netlify / Vercel
Drag‑and‑drop the unzipped folder on their dashboard or connect your GitHub repo—no build step needed.

### cPanel or shared hosting
Upload `index.html` to the `public_html/` directory.

All external libraries load from CDNs, so no additional build process is required.
